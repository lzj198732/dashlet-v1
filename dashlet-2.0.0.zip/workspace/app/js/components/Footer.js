import { t } from '../i18n.js';

export const Footer = (settings) => {
    const raw = settings.footerText;
    const text = ((raw && raw !== 'Powered by') ? raw : t('footer.poweredBy')).replace(/\s*Dashlet\s*$/i, '');
    return `
    <footer class="app-footer" ${settings.footerColor ? `style="color: ${settings.footerColor}"` : ''}>
        <div class="footer-content">
            <span class="footer-text">${text}</span>
            <a href="https://github.com/JaberQayad/dashlet" target="_blank" class="footer-link">Dashlet</a>
        </div>
    </footer>
`;
};
