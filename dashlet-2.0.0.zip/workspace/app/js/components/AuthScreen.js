import { t, i18n, getLanguage } from '../i18n.js';
import { login, setupAdmin, errorKey } from '../auth.js';

function langButton() {
    const next = getLanguage() === 'zh-CN' ? 'EN' : '中';
    return `<button type="button" class="icon-btn lang-btn" id="btn-lang" title="${t('lang.toggle')}">${next}</button>`;
}

function setupView() {
    return `
        <div class="auth-screen">
            <div class="auth-toolbar">${langButton()}</div>
            <form class="auth-card" id="auth-form">
                <h1>${t('auth.setupTitle')}</h1>
                <p class="auth-desc">${t('auth.setupDesc')}</p>
                <label>
                    <span>${t('auth.username')}</span>
                    <input type="text" id="auth-username" name="username" autocomplete="username" required minlength="2" maxlength="32">
                </label>
                <label>
                    <span>${t('auth.password')}</span>
                    <input type="password" id="auth-password" name="password" autocomplete="new-password" required minlength="8">
                </label>
                <label>
                    <span>${t('auth.confirmPassword')}</span>
                    <input type="password" id="auth-confirm" name="confirm" autocomplete="new-password" required minlength="8">
                </label>
                <p class="auth-error" id="auth-error" hidden></p>
                <button type="submit" class="auth-submit" id="auth-submit">${t('auth.setup')}</button>
            </form>
        </div>
    `;
}

function loginView() {
    return `
        <div class="auth-screen">
            <div class="auth-toolbar">${langButton()}</div>
            <form class="auth-card" id="auth-form">
                <h1>${t('auth.loginTitle')}</h1>
                <p class="auth-desc">${t('auth.loginDesc')}</p>
                <label>
                    <span>${t('auth.username')}</span>
                    <input type="text" id="auth-username" name="username" autocomplete="username" required>
                </label>
                <label>
                    <span>${t('auth.password')}</span>
                    <input type="password" id="auth-password" name="password" autocomplete="current-password" required>
                </label>
                <p class="auth-error" id="auth-error" hidden></p>
                <button type="submit" class="auth-submit" id="auth-submit">${t('auth.login')}</button>
            </form>
        </div>
    `;
}

function showError(message) {
    const el = document.getElementById('auth-error');
    if (!el) return;
    el.hidden = !message;
    el.textContent = message || '';
}

export function renderAuthScreen(root, status, onSuccess) {
    const paint = () => {
        root.innerHTML = status.setupRequired ? setupView() : loginView();
        const form = document.getElementById('auth-form');
        const langBtn = document.getElementById('btn-lang');
        if (langBtn) {
            langBtn.addEventListener('click', () => {
                i18n.setLanguage(getLanguage() === 'zh-CN' ? 'en' : 'zh-CN');
                paint();
            });
        }
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            showError('');
            const username = document.getElementById('auth-username').value.trim();
            const password = document.getElementById('auth-password').value;
            const submit = document.getElementById('auth-submit');
            if (!username || !password) {
                showError(t('auth.error.required'));
                return;
            }
            if (status.setupRequired) {
                const confirm = document.getElementById('auth-confirm').value;
                if (password !== confirm) {
                    showError(t('auth.error.mismatch'));
                    return;
                }
                if (password.length < 8) {
                    showError(t('auth.error.short'));
                    return;
                }
            }
            submit.disabled = true;
            try {
                if (status.setupRequired) {
                    await setupAdmin(username, password);
                } else {
                    await login(username, password);
                }
                onSuccess();
            } catch (err) {
                showError(t(errorKey(err)));
                submit.disabled = false;
            }
        });
    };
    paint();
}
