import { t, getLanguage } from '../i18n.js';

function escapeHtml(value) {
    return String(value || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

export const SettingsModal = (currentSettings, authUser) => {
    const lang = currentSettings.language || getLanguage();
    return `
    <div class="modal-backdrop" id="settings-backdrop">
        <div class="modal">
            <div class="modal-header">
                <h2>${t('settings.title')}</h2>
                <button class="close-btn" id="close-settings">
                    <span class="material-symbols-rounded">close</span>
                </button>
            </div>
            
            <div class="modal-body">
                <section>
                    <h3>${t('settings.appearance')}</h3>
                    <div class="setting-row">
                        <label for="setting-appTitle">${t('settings.appTitle')}</label>
                        <input type="text" id="setting-appTitle" value="${escapeHtml(currentSettings.appTitle || 'Dashlet')}" placeholder="Dashlet">
                    </div>
                    <div class="setting-row">
                        <label for="setting-greeting">${t('settings.greeting')}</label>
                        <input type="text" id="setting-greeting" value="${escapeHtml(currentSettings.greeting || '')}" placeholder="${t('settings.greeting')}">
                    </div>
                    <div class="setting-row">
                        <label for="setting-language">${t('settings.language')}</label>
                        <select id="setting-language">
                            <option value="zh-CN" ${lang === 'zh-CN' ? 'selected' : ''}>${t('lang.zh')}</option>
                            <option value="en" ${lang === 'en' ? 'selected' : ''}>${t('lang.en')}</option>
                        </select>
                    </div>
                    <div class="setting-row">
                        <label for="setting-theme">${t('settings.theme')}</label>
                        <select id="setting-theme">
                            <option value="system" ${currentSettings.theme === 'system' ? 'selected' : ''}>${t('theme.system')}</option>
                            <option value="dark" ${currentSettings.theme === 'dark' ? 'selected' : ''}>${t('theme.dark')}</option>
                            <option value="light" ${currentSettings.theme === 'light' ? 'selected' : ''}>${t('theme.light')}</option>
                        </select>
                    </div>
                    <div class="setting-row">
                        <label for="setting-accent">${t('settings.accent')}</label>
                        <input type="color" id="setting-accent" value="${currentSettings.accentColor || '#3b82f6'}">
                    </div>
                    <div class="setting-row">
                        <label for="setting-wallpaper">${t('settings.wallpaper')}</label>
                        <input type="text" id="setting-wallpaper" placeholder="https://..." value="${escapeHtml(currentSettings.wallpaper || '')}">
                    </div>
                     <div class="setting-row">
                        <label class="checkbox-label">
                            <input type="checkbox" id="setting-blur" ${currentSettings.blur ? 'checked' : ''}>
                            <span>${t('settings.blur')}</span>
                        </label>
                    </div>
                </section>

                <section>
                    <h3>${t('settings.search')}</h3>
                    <div class="setting-row">
                        <label class="checkbox-label">
                            <input type="checkbox" id="setting-searchEnabled" ${currentSettings.searchEnabled ? 'checked' : ''}>
                            <span>${t('settings.searchEnabled')}</span>
                        </label>
                    </div>
                    <div class="setting-row">
                        <label for="setting-search">${t('settings.searchProvider')}</label>
                        <input type="text" id="setting-search" placeholder="https://..." value="${escapeHtml(currentSettings.searchProvider || '')}">
                    </div>
                    <small class="help-text">${t('settings.searchHelp')}</small>
                </section>

                <section>
                    <h3>${t('settings.behavior')}</h3>
                    <div class="setting-row">
                        <label class="checkbox-label">
                            <input type="checkbox" id="setting-openNewTab" ${currentSettings.openNewTab ? 'checked' : ''}>
                            <span>${t('settings.openNewTab')}</span>
                        </label>
                    </div>
                    <div class="setting-row">
                        <label class="checkbox-label">
                            <input type="checkbox" id="setting-animations" ${currentSettings.animations ? 'checked' : ''}>
                            <span>${t('settings.animations')}</span>
                        </label>
                    </div>
                    <div class="setting-row">
                        <label class="checkbox-label">
                            <input type="checkbox" id="setting-disableDragDrop" ${currentSettings.disableDragDrop ? 'checked' : ''}>
                            <span>${t('settings.disableDnD')}</span>
                        </label>
                    </div>
                    <div class="setting-row">
                        <label class="checkbox-label">
                            <input type="checkbox" id="setting-dragDelay" ${currentSettings.dragDelay > 0 ? 'checked' : ''}>
                            <span>${t('settings.dragDelay')}</span>
                        </label>
                    </div>
                </section>

                <section>
                    <h3>${t('auth.access')}</h3>
                    <p class="access-note" id="auth-logged-in">${t('auth.loggedInAs', { name: authUser && authUser.username ? authUser.username : '-' })}</p>
                    <div class="setting-row setting-stack">
                        <label for="setting-currentPassword">${t('auth.currentPassword')}</label>
                        <input type="password" id="setting-currentPassword" autocomplete="current-password">
                    </div>
                    <div class="setting-row setting-stack">
                        <label for="setting-newPassword">${t('auth.newPassword')}</label>
                        <input type="password" id="setting-newPassword" autocomplete="new-password">
                    </div>
                    <div class="setting-row setting-stack">
                        <label for="setting-confirmPassword">${t('auth.confirmNewPassword')}</label>
                        <input type="password" id="setting-confirmPassword" autocomplete="new-password">
                    </div>
                    <p class="auth-error" id="password-msg" hidden></p>
                    <div class="setting-row actions-row">
                        <button id="btn-change-password">${t('auth.savePassword')}</button>
                        <button id="btn-logout" class="danger-btn">${t('auth.logout')}</button>
                    </div>
                    ${authUser && authUser.role === 'admin' ? `
                    <h3 style="margin-top:1.5rem">${t('auth.users')}</h3>
                    <div class="user-list" id="user-list"></div>
                    <div class="setting-row setting-stack">
                        <label for="setting-newUsername">${t('auth.newUsername')}</label>
                        <input type="text" id="setting-newUsername" autocomplete="off" maxlength="32">
                    </div>
                    <div class="setting-row setting-stack">
                        <label for="setting-newUserPassword">${t('auth.newUserPassword')}</label>
                        <input type="password" id="setting-newUserPassword" autocomplete="new-password">
                    </div>
                    <p class="auth-error" id="user-msg" hidden></p>
                    <div class="setting-row">
                        <button id="btn-add-user">${t('auth.addUser')}</button>
                    </div>
                    ` : ''}
                </section>

                <section>
                    <h3>${t('settings.config')}</h3>
                     <div class="setting-row actions-row">
                        <button id="btn-export">${t('settings.export')}</button>
                        <button id="btn-import">${t('settings.import')}</button>
                    </div>
                    <div class="setting-row">
                         <small class="help-text">
                            <strong>${t('settings.export')}:</strong> ${t('settings.exportHelp')}<br>
                            <strong>${t('settings.import')}:</strong> ${t('settings.importHelp')}
                        </small>
                    </div>
                    <div class="setting-row" style="margin-top: 1rem;">
                        <button id="btn-reset" class="danger-btn">${t('settings.reset')}</button>
                    </div>
                </section>

                <div class="modal-footer-info">
                    <span class="dot"></span>
                    <span id="settings-service-count">${t('settings.items', { n: 0 })}</span>
                </div>
            </div>
        </div>
    </div>
`;
};
