import { t, getLanguage } from '../i18n.js';

export const Header = (settings) => `
    <header class="app-header">
        <div class="brand">
            <h1 class="logo">${settings.appTitle || 'Dashlet'}</h1>
            <p class="app-desc">${settings.greeting || ''}</p>
        </div>

        ${settings.searchEnabled ? `
        <div class="search-container">
            <input type="text" id="app-search" class="app-search" placeholder="${t('search.placeholder')}" aria-label="${t('search.aria')}">
        </div>
        ` : ''}
        
        <div class="controls-right">
            <div class="controls">
                <div class="sort-selector" title="${t('sort.title')}">
                    <span class="material-symbols-rounded">sort</span>
                    <select id="select-sort">
                        <option value="manual" ${settings.sortBy === 'manual' ? 'selected' : ''}>${t('sort.manual')}</option>
                        <option value="name" ${settings.sortBy === 'name' ? 'selected' : ''}>${t('sort.name')}</option>
                        <option value="description" ${settings.sortBy === 'description' ? 'selected' : ''}>${t('sort.description')}</option>
                        <option value="url" ${settings.sortBy === 'url' ? 'selected' : ''}>${t('sort.url')}</option>
                    </select>
                </div>
                <button class="icon-btn lang-btn" id="btn-lang" title="${t('lang.toggle')}">${getLanguage() === 'zh-CN' ? 'EN' : '中'}</button>
                <button class="icon-btn" id="btn-layout" title="${t('layout.toggle')}">
                    <span class="material-symbols-rounded">${settings.layout === 'list' ? 'grid_view' : 'view_list'}</span>
                </button>
                <button class="icon-btn" id="btn-settings" title="${t('settings.open')}">
                    <span class="material-symbols-rounded">settings</span>
                </button>
            </div>
        </div>
    </header>
`;
