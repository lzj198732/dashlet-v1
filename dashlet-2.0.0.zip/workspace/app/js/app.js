import { ui } from './ui.js';
import { settings } from './store.js';
import { services } from './data.js';
import { pingServices } from './pingservices.js';
import { i18n } from './i18n.js';
import { getAuthStatus } from './auth.js';
import { renderAuthScreen } from './components/AuthScreen.js';

console.log("Dashlet Initialized - Version: AuthI18n-v1");

function bootDashboard(user) {
    settings.loadConfig().then(config => {
        if (config && config.services) {
            const mappedServices = config.services.map((s, i) => ({
                ...s,
                id: s.id || `json-${i}`
            }));
            services.sync(mappedServices);
            console.log(`Loaded ${mappedServices.length} services from config.`);
        }

        const preferred = settings.settings.language || i18n.getLanguage();
        i18n.setLanguage(preferred);
        pingServices.start();
        ui.start(user);
        if (!document.getElementById('custom-js')) {
            const script = document.createElement('script');
            script.id = 'custom-js';
            script.src = 'public/custom.js';
            script.defer = true;
            document.body.appendChild(script);
        }
    });
}

async function start() {
    const storedLang = localStorage.getItem('dashlet_lang');
    i18n.init(storedLang);
    document.documentElement.lang = i18n.getLanguage();

    const status = await getAuthStatus();
    if (status.unreachable) {
        bootDashboard(null);
        return;
    }
    if (status.authenticated) {
        bootDashboard(status.user);
        return;
    }

    const root = document.getElementById('app');
    renderAuthScreen(root, status, async () => {
        const next = await getAuthStatus();
        root.innerHTML = '';
        bootDashboard(next.user || { username: '', role: 'user' });
    });
}

start();
