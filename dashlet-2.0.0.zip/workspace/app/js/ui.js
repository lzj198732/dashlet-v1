import { settings } from './store.js';
import { services } from './data.js';
import { Header } from './components/Header.js';
import { Footer } from './components/Footer.js';
import { ServiceCard } from './components/ServiceCard.js';
import { SettingsModal } from './components/SettingsModal.js';
import { i18n, t, getLanguage } from './i18n.js';
import { changePassword, listUsers, addUser, removeUser, logout, errorKey } from './auth.js';

export class UI {
    constructor() {
        this.app = document.getElementById('app');
        this.authUser = null;
        this.sortable = null;
        this.booted = false;
    }

    start(authUser) {
        this.authUser = authUser || null;
        if (this.booted) {
            this.renderServices();
            this.applySettings(settings.settings);
            return;
        }
        this.booted = true;
        this.init();
    }

    init() {
        this.app.classList.add('app-layout');
        this.app.innerHTML = `
            ${Header(settings.settings)}
            <main id="main-content">
                <div class="content-grid" id="grid"></div>
            </main>
            ${Footer(settings.settings)}
            <div id="modal-container"></div>
        `;

        this.setupListeners();

        services.subscribe(() => this.renderServices());
        settings.subscribe((newSettings) => {
            this.applySettings(newSettings);
            this.renderServices();
        });
        i18n.subscribe(() => {
            this.applySettings(settings.settings);
            this.renderServices();
        });

        this.renderServices();
        this.applySettings(settings.settings);
        this.initSearch();
    }

    updateHeaderText(s) {
        const logo = document.querySelector('.logo');
        if (logo) logo.textContent = s.appTitle || 'Dashlet';
        const btnLayout = document.getElementById('btn-layout');
        if (btnLayout) {
            const icon = btnLayout.querySelector('span');
            if (icon) icon.textContent = s.layout === 'list' ? 'grid_view' : 'view_list';
        }
    }

    renderServices() {
        const grid = document.getElementById('grid');
        if (!grid) return;
        let allServices = services.getAll();
        const currentSettings = settings.settings;

        if (allServices.length === 0) {
            grid.innerHTML = `<div class="empty-state">${t('empty.services')}</div>`;
            return;
        }

        const sortBy = currentSettings.sortBy || 'manual';
        if (sortBy !== 'manual') {
            allServices = [...allServices].sort((a, b) => {
                const valA = (a[sortBy] || '').toLowerCase();
                const valB = (b[sortBy] || '').toLowerCase();
                return valA.localeCompare(valB);
            });
        }

        grid.innerHTML = allServices.map(s => ServiceCard(s, currentSettings)).join('');

        if (this.sortable) this.sortable.destroy();
        if (sortBy !== 'manual' || currentSettings.disableDragDrop) return;

        this.sortable = new Sortable(grid, {
            animation: 150,
            ghostClass: 'sortable-ghost',
            delay: currentSettings.dragDelay || 0,
            delayOnTouchOnly: true,
            onEnd: () => {
                const ids = Array.from(grid.children).map(el => el.getAttribute('data-id'));
                const reordered = ids.map(id => services.getAll().find(s => s.id === id)).filter(Boolean);
                if (reordered.length === services.getAll().length) {
                    services.replaceAll(reordered);
                }
            }
        });
    }

    setupListeners() {
        this.app.addEventListener('click', (e) => {
            const btnSettings = e.target.closest('#btn-settings');
            if (btnSettings) this.openSettings();

            const btnLayout = e.target.closest('#btn-layout');
            if (btnLayout) {
                const current = settings.get('layout') || 'grid';
                const next = current === 'list' ? 'grid' : 'list';
                settings.set('layout', next);
            }

            const btnLang = e.target.closest('#btn-lang');
            if (btnLang) {
                const next = getLanguage() === 'zh-CN' ? 'en' : 'zh-CN';
                i18n.setLanguage(next);
                settings.set('language', next);
            }
        });

        this.app.addEventListener('change', (e) => {
            if (e.target.id === 'select-sort') {
                settings.set('sortBy', e.target.value);
            }
        });

        this.app.addEventListener('keydown', (e) => {
            if (e.target.id === 'app-search' && e.key === 'Enter') {
                this.performSearch(e.target.value);
            }
        });
    }

    initSearch() {
    }

    performSearch(query) {
        if (!query) return;
        const provider = settings.get('searchProvider');
        if (!provider) return;

        let url = provider;
        if (url.includes('%s')) {
            url = url.replace('%s', encodeURIComponent(query));
        } else {
            url += encodeURIComponent(query);
        }
        window.open(url, settings.get('openNewTab') ? '_blank' : '_self');
    }

    setMsg(id, text, isError = true) {
        const el = document.getElementById(id);
        if (!el) return;
        el.hidden = !text;
        el.textContent = text || '';
        el.style.color = isError ? '#ff6b6b' : '#34d399';
    }

    async refreshUsers() {
        const list = document.getElementById('user-list');
        if (!list) return;
        try {
            const data = await listUsers();
            const users = data.users || [];
            const escapeHtml = (value) => String(value || '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;');
            list.innerHTML = users.map((u) => `
                <div class="user-row" data-id="${u.id}">
                    <div class="user-meta">
                        <span class="user-name">${escapeHtml(u.username)}</span>
                        <span class="user-role">${u.role === 'admin' ? t('auth.role.admin') : t('auth.role.user')}</span>
                    </div>
                    <button class="danger-btn btn-remove-user" data-id="${u.id}" data-name="${escapeHtml(u.username)}">${t('auth.deleteUser')}</button>
                </div>
            `).join('');
        } catch (err) {
            list.innerHTML = `<p class="access-note">${t(errorKey(err))}</p>`;
        }
    }

    openSettings() {
        const container = document.getElementById('modal-container');
        container.innerHTML = SettingsModal(settings.settings, this.authUser);

        const countEl = document.getElementById('settings-service-count');
        if (countEl) countEl.textContent = t('settings.items', { n: services.getAll().length });

        const close = () => { container.innerHTML = ''; };
        document.getElementById('close-settings').addEventListener('click', close);
        document.getElementById('settings-backdrop').addEventListener('click', (e) => {
            if (e.target.id === 'settings-backdrop') close();
        });

        const bindCheckbox = (id, key) => {
            const el = document.getElementById(id);
            if (el) el.addEventListener('change', (e) => settings.set(key, e.target.checked));
        };
        const bindSelect = (id, key) => {
            const el = document.getElementById(id);
            if (el) el.addEventListener('change', (e) => settings.set(key, e.target.value));
        };
        const bindInput = (id, key) => {
            const el = document.getElementById(id);
            if (el) el.addEventListener('input', (e) => settings.set(key, e.target.value));
        };

        bindSelect('setting-theme', 'theme');
        bindCheckbox('setting-openNewTab', 'openNewTab');
        bindCheckbox('setting-animations', 'animations');
        bindCheckbox('setting-blur', 'blur');
        bindCheckbox('setting-disableDragDrop', 'disableDragDrop');
        bindCheckbox('setting-searchEnabled', 'searchEnabled');

        const langEl = document.getElementById('setting-language');
        if (langEl) {
            langEl.addEventListener('change', (e) => {
                const next = e.target.value;
                i18n.setLanguage(next);
                settings.set('language', next);
                this.openSettings();
            });
        }

        const dragDelayEl = document.getElementById('setting-dragDelay');
        if (dragDelayEl) {
            dragDelayEl.addEventListener('change', (e) => {
                settings.set('dragDelay', e.target.checked ? 400 : 0);
            });
        }

        bindInput('setting-accent', 'accentColor');
        bindInput('setting-wallpaper', 'wallpaper');
        bindInput('setting-appTitle', 'appTitle');
        bindInput('setting-greeting', 'greeting');
        bindInput('setting-search', 'searchProvider');

        document.getElementById('btn-reset').addEventListener('click', () => {
            if (confirm(t('confirm.reset'))) {
                settings.reset();
                close();
            }
        });

        document.getElementById('btn-export').addEventListener('click', () => {
            const configObj = {
                settings: settings.settings,
                services: services.getAll()
            };
            const jsonStr = JSON.stringify(configObj, null, 2);
            const dataStr = "data:application/json;charset=utf-8," + encodeURIComponent(jsonStr);
            const anchor = document.createElement('a');
            anchor.setAttribute("href", dataStr);
            anchor.setAttribute("download", "config.json");
            document.body.appendChild(anchor);
            anchor.click();
            anchor.remove();
        });

        document.getElementById('btn-import').addEventListener('click', () => {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.json';
            input.onchange = (e) => {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = (ev) => {
                        const content = ev.target.result;
                        let data = null;
                        try {
                            data = JSON.parse(content);
                        } catch (err) {
                            console.error(err);
                            alert(t('alert.importFail', { msg: err.message }));
                            return;
                        }

                        if (data && data.settings) {
                            Object.keys(settings.settings).forEach(k => {
                                if (data.settings[k] !== undefined) settings.set(k, data.settings[k]);
                            });
                            if (data.settings.language) i18n.setLanguage(data.settings.language);
                        }
                        if (data && data.services) {
                            services.replaceAll(data.services);
                        }
                        alert(t('alert.importOk'));
                        close();
                    };
                    reader.readAsText(file);
                }
            };
            input.click();
        });

        const btnChange = document.getElementById('btn-change-password');
        if (btnChange) {
            btnChange.addEventListener('click', async () => {
                const currentPassword = document.getElementById('setting-currentPassword').value;
                const newPassword = document.getElementById('setting-newPassword').value;
                const confirmPassword = document.getElementById('setting-confirmPassword').value;
                if (!currentPassword || !newPassword || !confirmPassword) {
                    this.setMsg('password-msg', t('auth.error.required'));
                    return;
                }
                if (newPassword !== confirmPassword) {
                    this.setMsg('password-msg', t('auth.error.mismatch'));
                    return;
                }
                if (newPassword.length < 8) {
                    this.setMsg('password-msg', t('auth.error.short'));
                    return;
                }
                try {
                    await changePassword(currentPassword, newPassword);
                    document.getElementById('setting-currentPassword').value = '';
                    document.getElementById('setting-newPassword').value = '';
                    document.getElementById('setting-confirmPassword').value = '';
                    this.setMsg('password-msg', t('auth.success.password'), false);
                } catch (err) {
                    this.setMsg('password-msg', t(errorKey(err)));
                }
            });
        }

        const btnLogout = document.getElementById('btn-logout');
        if (btnLogout) {
            btnLogout.addEventListener('click', async () => {
                if (!confirm(t('auth.confirmLogout'))) return;
                try {
                    await logout();
                } catch (e) {
                }
                window.location.reload();
            });
        }

        const btnAddUser = document.getElementById('btn-add-user');
        if (btnAddUser) {
            this.refreshUsers();
            btnAddUser.addEventListener('click', async () => {
                const username = document.getElementById('setting-newUsername').value.trim();
                const password = document.getElementById('setting-newUserPassword').value;
                if (!username || !password) {
                    this.setMsg('user-msg', t('auth.error.required'));
                    return;
                }
                if (username.length < 2 || username.length > 32) {
                    this.setMsg('user-msg', t('auth.error.username'));
                    return;
                }
                if (password.length < 8) {
                    this.setMsg('user-msg', t('auth.error.short'));
                    return;
                }
                try {
                    await addUser(username, password);
                    document.getElementById('setting-newUsername').value = '';
                    document.getElementById('setting-newUserPassword').value = '';
                    this.setMsg('user-msg', t('auth.success.user'), false);
                    this.refreshUsers();
                } catch (err) {
                    this.setMsg('user-msg', t(errorKey(err)));
                }
            });

            const list = document.getElementById('user-list');
            if (list) {
                list.addEventListener('click', async (e) => {
                    const btn = e.target.closest('.btn-remove-user');
                    if (!btn) return;
                    const name = btn.getAttribute('data-name');
                    if (!confirm(t('auth.confirmDelete', { name }))) return;
                    try {
                        await removeUser(btn.getAttribute('data-id'));
                        this.setMsg('user-msg', t('auth.success.deleted'), false);
                        this.refreshUsers();
                    } catch (err) {
                        this.setMsg('user-msg', t(errorKey(err)));
                    }
                });
            }
        }
    }

    applySettings(s) {
        if (s.theme === 'system') {
            const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            document.body.setAttribute('data-theme', isDark ? 'dark' : 'light');
        } else {
            document.body.setAttribute('data-theme', s.theme);
        }

        if (s.accentColor) {
            document.documentElement.style.setProperty('--primary-color', s.accentColor);
        }

        if (s.wallpaper) {
            document.body.style.backgroundImage = `url('${s.wallpaper}')`;
            document.body.style.backgroundSize = 'cover';
            document.body.style.backgroundPosition = 'center';
            document.body.style.backgroundAttachment = 'fixed';
        } else {
            document.body.style.backgroundImage = '';
        }

        if (!s.blur) document.body.classList.add('no-blur');
        else document.body.classList.remove('no-blur');

        if (!s.animations) document.body.classList.add('no-animations');
        else document.body.classList.remove('no-animations');

        const grid = document.getElementById('grid');
        if (grid) {
            if (s.layout === 'list') grid.classList.add('list-view');
            else grid.classList.remove('list-view');
        }

        const oldHeader = document.querySelector('header');
        if (oldHeader) {
            const temp = document.createElement('div');
            temp.innerHTML = Header(s);
            oldHeader.replaceWith(temp.firstElementChild);
        }

        this.updateHeaderText(s);

        const oldFooter = document.querySelector('footer');
        if (oldFooter) {
            const temp = document.createElement('div');
            temp.innerHTML = Footer(s);
            oldFooter.replaceWith(temp.firstElementChild);
        }

        this.updateHeaderText(s);
    }
}

export const ui = new UI();
