async function request(url, options = {}) {
    const res = await fetch(url, {
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
        ...options
    });
    let data = null;
    try {
        data = await res.json();
    } catch (e) {
        data = { ok: false, error: 'generic' };
    }
    if (!res.ok) {
        const err = new Error(data && data.error ? data.error : 'generic');
        err.status = res.status;
        err.code = data && data.error ? data.error : 'generic';
        throw err;
    }
    return data;
}

export async function getAuthStatus() {
    try {
        return await request('/api/auth/status');
    } catch (e) {
        return { ok: false, authenticated: false, setupRequired: false, unreachable: true };
    }
}

export function login(username, password) {
    return request('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username, password })
    });
}

export function setupAdmin(username, password) {
    return request('/api/auth/setup', {
        method: 'POST',
        body: JSON.stringify({ username, password })
    });
}

export function logout() {
    return request('/api/auth/logout', { method: 'POST' });
}

export function changePassword(currentPassword, newPassword) {
    return request('/api/auth/password', {
        method: 'POST',
        body: JSON.stringify({ currentPassword, newPassword })
    });
}

export function listUsers() {
    return request('/api/auth/users');
}

export function addUser(username, password, role = 'user') {
    return request('/api/auth/users', {
        method: 'POST',
        body: JSON.stringify({ username, password, role })
    });
}

export function removeUser(id) {
    return request(`/api/auth/users/${encodeURIComponent(id)}`, { method: 'DELETE' });
}

export function errorKey(err) {
    const code = (err && (err.code || err.message)) || 'generic';
    const map = {
        mismatch: 'auth.error.mismatch',
        short: 'auth.error.short',
        invalid: 'auth.error.invalid',
        required: 'auth.error.required',
        exists: 'auth.error.exists',
        locked: 'auth.error.locked',
        lastAdmin: 'auth.error.lastAdmin',
        self: 'auth.error.self',
        username: 'auth.error.username',
        unauthorized: 'auth.error.invalid'
    };
    return map[code] || 'auth.error.generic';
}
