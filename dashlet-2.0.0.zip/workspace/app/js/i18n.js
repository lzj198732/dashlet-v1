const STRINGS = {
    en: {
        'search.placeholder': 'Search...',
        'search.aria': 'Search',
        'sort.title': 'Sort By',
        'sort.manual': 'Manual',
        'sort.name': 'Name',
        'sort.description': 'Description',
        'sort.url': 'URL',
        'layout.toggle': 'Toggle Layout',
        'settings.open': 'Settings',
        'settings.title': 'Settings',
        'settings.appearance': 'Appearance',
        'settings.appTitle': 'App Title',
        'settings.greeting': 'Greeting',
        'settings.theme': 'Theme',
        'theme.system': 'System',
        'theme.dark': 'Dark',
        'theme.light': 'Light',
        'settings.accent': 'Accent Color',
        'settings.wallpaper': 'Background URL',
        'settings.blur': 'Glass Blur Effect',
        'settings.language': 'Language',
        'lang.zh': '中文',
        'lang.en': 'English',
        'lang.toggle': 'Switch language',
        'settings.search': 'Search',
        'settings.searchEnabled': 'Enable Search',
        'settings.searchProvider': 'Search Provider',
        'settings.searchHelp': 'Query placeholder should be %s or at the end of the URL.',
        'settings.behavior': 'Behavior',
        'settings.openNewTab': 'Open links in new tab',
        'settings.animations': 'Enable animations',
        'settings.disableDnD': 'Disable Drag & Drop',
        'settings.dragDelay': 'Mobile-Safe Drag (Long Press)',
        'settings.config': 'Configuration',
        'settings.export': 'Export Config',
        'settings.import': 'Import Config',
        'settings.exportHelp': 'Download current settings as config.json.',
        'settings.importHelp': 'Load settings/services from a JSON file into the current session. (Does not save to server).',
        'settings.reset': 'Reset to Defaults',
        'settings.items': '{n} items',
        'empty.services': 'No services added yet.',
        'confirm.reset': 'Reset all settings to default?',
        'alert.importFail': 'Failed to parse file: {msg}',
        'alert.importOk': 'Configuration imported.',
        'footer.poweredBy': 'Powered by',
        'auth.setupTitle': 'Initial Setup',
        'auth.setupDesc': 'Create an admin account to keep this private dashboard locked.',
        'auth.loginTitle': 'Sign In',
        'auth.loginDesc': 'This is a private dashboard. Sign in to continue.',
        'auth.username': 'Username',
        'auth.password': 'Password',
        'auth.confirmPassword': 'Confirm Password',
        'auth.login': 'Sign In',
        'auth.setup': 'Create Admin Account',
        'auth.logout': 'Sign Out',
        'auth.changePassword': 'Change Password',
        'auth.currentPassword': 'Current Password',
        'auth.newPassword': 'New Password',
        'auth.confirmNewPassword': 'Confirm New Password',
        'auth.savePassword': 'Update Password',
        'auth.users': 'Users',
        'auth.addUser': 'Add User',
        'auth.deleteUser': 'Remove',
        'auth.access': 'Access',
        'auth.loggedInAs': 'Signed in as {name}',
        'auth.role.admin': 'Admin',
        'auth.role.user': 'User',
        'auth.error.mismatch': 'Passwords do not match.',
        'auth.error.short': 'Password must be at least 8 characters.',
        'auth.error.invalid': 'Invalid username or password.',
        'auth.error.required': 'Please fill in all fields.',
        'auth.error.exists': 'Username already exists.',
        'auth.error.generic': 'Request failed. Please try again.',
        'auth.error.locked': 'Too many attempts. Try again later.',
        'auth.error.lastAdmin': 'Cannot remove the last admin.',
        'auth.error.self': 'You cannot remove your own account.',
        'auth.error.username': 'Username must be 2-32 characters.',
        'auth.success.password': 'Password updated.',
        'auth.success.user': 'User created.',
        'auth.success.deleted': 'User removed.',
        'auth.confirmDelete': 'Remove user {name}?',
        'auth.confirmLogout': 'Sign out of the dashboard?',
        'auth.newUsername': 'New username',
        'auth.newUserPassword': 'New user password'
    },
    'zh-CN': {
        'search.placeholder': '搜索...',
        'search.aria': '搜索',
        'sort.title': '排序方式',
        'sort.manual': '手动',
        'sort.name': '名称',
        'sort.description': '描述',
        'sort.url': '链接',
        'layout.toggle': '切换布局',
        'settings.open': '设置',
        'settings.title': '设置',
        'settings.appearance': '外观',
        'settings.appTitle': '应用标题',
        'settings.greeting': '问候语',
        'settings.theme': '主题',
        'theme.system': '跟随系统',
        'theme.dark': '深色',
        'theme.light': '浅色',
        'settings.accent': '强调色',
        'settings.wallpaper': '背景图 URL',
        'settings.blur': '毛玻璃效果',
        'settings.language': '语言',
        'lang.zh': '中文',
        'lang.en': 'English',
        'lang.toggle': '切换语言',
        'settings.search': '搜索',
        'settings.searchEnabled': '启用搜索',
        'settings.searchProvider': '搜索引擎',
        'settings.searchHelp': '查询占位符使用 %s，或放在 URL 末尾。',
        'settings.behavior': '行为',
        'settings.openNewTab': '在新标签页打开链接',
        'settings.animations': '启用动画',
        'settings.disableDnD': '禁用拖拽排序',
        'settings.dragDelay': '移动端长按拖拽',
        'settings.config': '配置',
        'settings.export': '导出配置',
        'settings.import': '导入配置',
        'settings.exportHelp': '将当前设置下载为 config.json。',
        'settings.importHelp': '从 JSON 文件加载设置和服务到当前会话（不会保存到服务器）。',
        'settings.reset': '恢复默认',
        'settings.items': '{n} 个项目',
        'empty.services': '还没有添加任何服务。',
        'confirm.reset': '确定将所有设置恢复为默认值？',
        'alert.importFail': '文件解析失败：{msg}',
        'alert.importOk': '配置已导入。',
        'footer.poweredBy': '技术支持',
        'auth.setupTitle': '初始化',
        'auth.setupDesc': '创建管理员账号，保护这个私人仪表盘。',
        'auth.loginTitle': '登录',
        'auth.loginDesc': '这是私人仪表盘，请登录后继续。',
        'auth.username': '用户名',
        'auth.password': '密码',
        'auth.confirmPassword': '确认密码',
        'auth.login': '登录',
        'auth.setup': '创建管理员',
        'auth.logout': '退出登录',
        'auth.changePassword': '修改密码',
        'auth.currentPassword': '当前密码',
        'auth.newPassword': '新密码',
        'auth.confirmNewPassword': '确认新密码',
        'auth.savePassword': '更新密码',
        'auth.users': '用户',
        'auth.addUser': '添加用户',
        'auth.deleteUser': '移除',
        'auth.access': '访问管理',
        'auth.loggedInAs': '当前用户：{name}',
        'auth.role.admin': '管理员',
        'auth.role.user': '用户',
        'auth.error.mismatch': '两次输入的密码不一致。',
        'auth.error.short': '密码至少需要 8 位。',
        'auth.error.invalid': '用户名或密码错误。',
        'auth.error.required': '请填写全部字段。',
        'auth.error.exists': '用户名已存在。',
        'auth.error.generic': '请求失败，请重试。',
        'auth.error.locked': '尝试次数过多，请稍后再试。',
        'auth.error.lastAdmin': '不能移除最后一位管理员。',
        'auth.error.self': '不能移除当前登录账号。',
        'auth.error.username': '用户名长度为 2-32 个字符。',
        'auth.success.password': '密码已更新。',
        'auth.success.user': '用户已创建。',
        'auth.success.deleted': '用户已移除。',
        'auth.confirmDelete': '确定移除用户 {name}？',
        'auth.confirmLogout': '确定退出登录？',
        'auth.newUsername': '新用户名',
        'auth.newUserPassword': '新用户密码'
    }
};

const LANG_KEY = 'dashlet_lang';

function normalize(lang) {
    if (!lang) return null;
    const value = String(lang).toLowerCase();
    if (value.startsWith('zh')) return 'zh-CN';
    if (value.startsWith('en')) return 'en';
    return null;
}

function detect() {
    const nav = (navigator.language || navigator.userLanguage || '').toLowerCase();
    return nav.startsWith('zh') ? 'zh-CN' : 'en';
}

class I18n {
    constructor() {
        this.lang = 'zh-CN';
        this.listeners = [];
    }

    init(preferred) {
        this.setLanguage(normalize(preferred) || normalize(localStorage.getItem(LANG_KEY)) || detect(), false);
        return this.lang;
    }

    getLanguage() {
        return this.lang;
    }

    setLanguage(lang, persist = true) {
        const next = normalize(lang) || 'en';
        if (next === this.lang && persist) {
            localStorage.setItem(LANG_KEY, next);
            document.documentElement.lang = next;
            return;
        }
        this.lang = next;
        if (persist) localStorage.setItem(LANG_KEY, next);
        document.documentElement.lang = next;
        this.listeners.forEach((cb) => cb(next));
    }

    t(key, vars = {}) {
        const table = STRINGS[this.lang] || STRINGS.en;
        let str = table[key] || STRINGS.en[key] || key;
        return str.replace(/\{(\w+)\}/g, (_, name) => (vars[name] !== undefined ? String(vars[name]) : ''));
    }

    subscribe(cb) {
        this.listeners.push(cb);
        return () => {
            this.listeners = this.listeners.filter((fn) => fn !== cb);
        };
    }
}

export const i18n = new I18n();
export const t = (key, vars) => i18n.t(key, vars);
export const getLanguage = () => i18n.getLanguage();
